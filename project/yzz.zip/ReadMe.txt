1. Group NUMBER
	Group 24

2.
Name: YE ZHIZHEN
SID: 1155046993

Name: 
SID: 1155049332	


3. Classes Description

Console.java: The entry point for the program
Administrator.java: The class for Administrator
Manager.java: The class for manager
Salesperson.java: The class for Salesperson
Errors.java: The class for exception handler


	
4.  Compile And Read Data
	
	At current directory, say,  '/b',
	create a directory named 'yzz'.
	copy all java files and jar and data files into yzz.
	
	At '/b',
	Run following:
		//compile
		javac yzz/*.java
		//run
		java -cp './:./yzz/ojdbc6.jar' yzz.Console
	
	Suppose you put datafile in /b/yzz/dataset
	
	then when you are prompted to input folder, you should type yzz/dataset
	