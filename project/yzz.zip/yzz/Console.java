package yzz;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class Console {
	private String account;
	private String password;
	private int choice = 0;
	protected static Connection cn;
	protected static Scanner s = new Scanner(System.in);
	private final String[] mainmenu={"Operations for administrator", "Operations for salesperson",
			"Operations for manager", "Exit this program"
			};
	
	private void loadDriver(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(Exception e){
			System.out.println("Unable to load the driver class!");
			System.exit(1);
		}
	}
	
	public Connection connect(){
		while(true)
		{
		System.out.print("Input account: ");
		System.out.flush();
		this.account = s.nextLine();
		System.out.print("Input password: ");
		this.password = s.nextLine();
		Connection conn = null;
		try{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@db12.cse.cuhk.edu.hk:1521:db12",
				account, password);
		}
		catch(SQLException e){
			System.out.println("\nError state: " + e.getSQLState());
			System.out.println(e.getMessage());
			continue;
		}
		return conn;
		}
	}
	
	private void printMenu(String[] menus)
	{
		int i=1;
		System.out.println("What kinds of operation would you like to perform?");
		StringBuffer sb = new StringBuffer(120);
		for (String item: menus)
		{
			sb.append(i++).append(". ").append(item).append("\n");
		}
		sb.append("Enter Your Choice: ");
		System.out.print(sb.toString());
	}
	
	protected static int read(int upperbound)
	{
		int choice = 0;
		try{
			choice = s.nextInt();
			//clean this line
			s.nextLine();
			if(choice >upperbound || choice<1)
			{
				System.err.println("Please input between 1-"+upperbound);
				return 0;
			}
		}
		catch(InputMismatchException i){
			System.out.println("Please input an integer!");
			return 0;
		}
		catch(NoSuchElementException i){
			System.out.println("Element does not exist!");
			return 0;
		}
		return choice;
	}
	
	private void adminloop()
	{
		while(true)
		{
			System.out.println("\n-----Opertions for administrator menu-----");
			printMenu(Administrator.adminmenu);
			this.choice = read(Administrator.adminmenu.length);
			switch(this.choice)
			{
				case 1:
					Administrator.createTable();
					break;
				case 2:
					Administrator.deleteTable();
					break;
				case 3:
					Administrator.loadData();
					break;
				case 4:
					Administrator.shownumber();
					break;
				case 5:
					return;
			}
			//block the process so that user can see results
			System.out.println("Press enter to continue...");
			s.nextLine();
		}
		
	}
	
	private void salesloop()
	{
		while(true)
		{
			System.out.println("\n-----Opertions for salesperson menu-----");
			printMenu(Salesperson.salemenu);
			this.choice = read(Salesperson.salemenu.length);
			switch(this.choice)
			{
			
				case 1:
					Salesperson.search();
					break;
				case 2:
					Salesperson.sell();
					break;
				case 3:
					return;
			}
			//block
			System.out.println("Press enter to continue...");
			s.nextLine();
		}
	}
	
	private void managerloop()
	{
		while(true)
		{
			System.out.println("\n-----Opertions for salesperson menu-----");
			printMenu(Manager.manmenu);
			this.choice = read(Manager.manmenu.length);
			switch(this.choice)
			{
				case 1:
					Manager.showrecord();
					break;
				case 2:
					Manager.showsalesvalue();
					break;
				case 3:
					Manager.showpopular();
					break;
				case 4:
					return;
			}
			//block
			System.out.println("Press enter to continue...");
			s.nextLine();
		}
	}
	
	public void mainloop()
	{
		while (true)
		{
			System.out.println("\n-----Main Menu-----");
			printMenu(mainmenu);
			this.choice = read(mainmenu.length);
			
			switch(choice)
			{
				case 1:
					adminloop();
					break;
				case 2:
					salesloop();
					break;
				case 3:
					managerloop();
					break;
				case 4:
					System.out.println("Bye!");
					System.exit(0);
					break;
			}
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Console c = new Console();
		c.loadDriver();
		cn = c.connect();
		System.out.println("Welcome to sales system!");
		c.mainloop();
		
	}
	
}



