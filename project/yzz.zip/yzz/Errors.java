package yzz;

import java.sql.SQLException;

public class Errors {
	
	public static void handleSQL(String name, SQLException e){
		System.out.print("\nFor " + name);
		System.out.println(": Error STATE: " + e.getSQLState());
		System.out.println("With the following message: " + e.getMessage());
	}
	public static void handleCreateSQL(SQLException e){
		System.out.println("Fail to create statement...\nError state:" + e.getSQLState());
		System.out.println(e.getMessage());
	}
	public static void handleCloseSQL(SQLException e){
		System.out.println("Fail to close statement...\nError state:" + e.getSQLState());
		System.out.println(e.getMessage());
	}
}
