package yzz;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;



public class Administrator {
	private static final String[] tablenames = { "category", "manufacturer", "part", "salesperson", "transaction" };
	public static final String[] adminmenu = { "Create all tables", "Delete all tables", "Load from datafile",
			"Show number of records in each table", "Return to the main menu" };
	private static final String[] t_create = { "CREATE TABLE category" + "(cID NUMBER(1,0),"
			+ "cName VARCHAR(20) NOT NULL," + "CONSTRAINT Checkdigit CHECK (LENGTH(cID)=1)," + "PRIMARY KEY (cID))",

			"CREATE TABLE manufacturer" + "(mID NUMBER(2,0) NOT NULL," + "mName VARCHAR(20) NOT NULL,"
					+ "mAddress VARCHAR(50) NOT NULL," + "mPhoneNumber NUMBER(8,0) NOT NULL,"
					+ "mWarrantyPeriod NUMBER(1,0) NOT NULL,"
					+ "totalvalue INTEGER DEFAULT 0, "
					+ "CHECK (LENGTH(mWarrantyPeriod)=1 AND LENGTH(mPhoneNumber)=8)," + "PRIMARY KEY (mID))",

			"CREATE TABLE part" + "(pID NUMBER(3,0)," + ""
					+ "pName VARCHAR(20) NOT NULL," + 
					"pPrice NUMBER(5,0) NOT NULL,"
					+ "mID NUMBER(2,0) NOT NULL," + "cID NUMBER(1,0) NOT NULL,"
					+ "pAvailableQuantity NUMBER(2,0) NOT NULL," + "PRIMARY KEY (pID),"
					+ "FOREIGN KEY (mID) REFERENCES manufacturer ON DELETE CASCADE,"
					+ "FOREIGN KEY (cID) REFERENCES category ON DELETE CASCADE)",

			"CREATE TABLE salesperson" + "(sID NUMBER(2,0)," + "sName VARCHAR(20) NOT NULL,"
					+ "sAddress VARCHAR(50) NOT NULL," + "sPhoneNumber NUMBER(8,0) NOT NULL," + "PRIMARY KEY (sID),"
					+ "CONSTRAINT phonelength CHECK (LENGTH(sPhoneNumber)=8))",

			"CREATE TABLE transaction" + "(tID NUMBER(4,0)," + "pID NUMBER(3,0)," + "sID NUMBER(2,0),"
					+ "tDate DATE NOT NULL," + "PRIMARY KEY (tID),"
					+ "FOREIGN KEY (pID) REFERENCES part ON DELETE CASCADE,"
					+ "FOREIGN KEY (sID) REFERENCES salesperson ON DELETE CASCADE)" };

	private static final String[] t_drop = { "DROP TABLE salesperson CASCADE CONSTRAINTS",
			"DROP TABLE category CASCADE CONSTRAINTS", "DROP TABLE manufacturer CASCADE CONSTRAINTS",
			"DROP TABLE part CASCADE CONSTRAINTS", "DROP TABLE transaction CASCADE CONSTRAINTS", };

	private static final String trigger_c ="CREATE OR REPLACE TRIGGER MFV AFTER INSERT ON transaction "
			+ "FOR EACH ROW "
			+ "BEGIN "
			+ "UPDATE manufacturer M SET M.totalvalue = M.totalvalue + "
			+ "(SELECT P1.pPrice FROM part P1 WHERE P1.pID = :NEW.pID) "
			+ "WHERE M.mID = (SELECT P.mID FROM part P WHERE p.pID = :NEW.pID);END;";
	private static final String trigger_d = "DROP TRIGGER MFV";
	public static void createTable() {
		boolean flag = true;
		Statement st;
		try {
			st = Console.cn.createStatement();
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
			return;
		}

		// do create operation
		for (String item : t_create) {
			try {
				st.execute(item);
			} catch (SQLException e) {
				flag = false;
				Errors.handleSQL(item, e);
				// System.out.println();
			}
		}
		
		try {
			st.execute(trigger_c);
		} catch (SQLException e1) {
			Errors.handleSQL(trigger_c, e1);
		}
		try {
			st.close();
		} catch (SQLException e) {
			Errors.handleCloseSQL(e);
		}
		if (flag)
			System.out.println("\nProcessing...Done! Database is initialized!");
		
	}

	public static void deleteTable() {
		Statement st;
		boolean flag = true;
		try {
			st = Console.cn.createStatement();
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
			return;
		}
		try {
			st.execute(trigger_d);
		} catch (SQLException e1) {
			Errors.handleSQL(trigger_d, e1);
		}
		// do drop operation
		for (String item : t_drop) {
			try {
				st.execute(item);
			} catch (SQLException e) {
				flag = false;
				Errors.handleSQL(item, e);
			}
		}
		try {
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Errors.handleCloseSQL(e);
		}
		//System.out.println(trigger);
		if (flag)
			System.out.println("Processing...Done! Database is removed!");

	}

	public static void insertinterface(String tablename, String[] attributes, InputStream inp) {
		Scanner sc = new Scanner(inp);
		PreparedStatement ps;
		String prefix = "";
		StringBuffer sb = new StringBuffer(80);
		sb.append("INSERT INTO ").append(tablename).append("(");
		for (String item : attributes) {
			sb.append(prefix);
			sb.append(item);
			prefix = ",";
		}
		sb.append(")VALUES(");
		prefix = "";
		for (int i = 0; i < attributes.length; i++) {
			sb.append(prefix);
			sb.append("?");
			prefix = ",";
		}
		sb.append(")");
		System.out.println(sb.toString());
		try {
			ps = Console.cn.prepareStatement(sb.toString());
		} catch (SQLException e) {
			Errors.handleSQL(tablename, e);
			sc.close();
			return;
		}
		// read the file and fulfill the blank
		while (sc.hasNextLine()) {
			String[] tem = sc.nextLine().split("\t");
			//System.out.printf(tablename + " :Column length: %d\n",tem.length);
			for (int i = 0; i < tem.length; i++) {
				try {
					try {
						ps.setInt(i+1, Integer.parseInt(tem[i]));
					} catch (NumberFormatException e) {
						if (tablename.equals("transaction")&&i==3) {
							DateFormat source = new SimpleDateFormat("dd/MM/yyyy");
							DateFormat des = new SimpleDateFormat("yyyy-MM-dd");
							try {
								ps.setDate(i+1, java.sql.Date.valueOf(des.format(source.parse(tem[i]))));
							} catch (ParseException e1) {
								System.out.println("Date parse error...");
							}
						}
						else
							ps.setString(i+1, tem[i]);
					}
				} catch (SQLException e) {
					Errors.handleSQL(tablename, e);
				}
			}
			// execute
			try {
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.print("For " + tablename);
				System.out.println(": Error STATE: " + e.getSQLState());
				System.out.println("With the following message: " + e.getMessage());
			}
		}
		try {
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Errors.handleCloseSQL(e);
		}
		sc.close();
	}

	public static void loadData() {
		
		String[][] fieldname = { { "cID", "cName" }, { "mID", "mName", "mAddress", "mPhoneNumber", "mWarrantyPeriod" },
				{ "pID", "pName", "pPrice", "mID", "cID", "pAvailableQuantity" },
				{ "sID", "sName", "sAddress", "sPhoneNumber" }, { "tID", "pID", "sID", "tDate" } };
		System.out.println("Type in the Source Data Folder Path");
		//System.out.println(new File("").getPath()); for viewing current directory
		//no matter relative or absolute path
		String folderpath = Console.s.nextLine();
		InputStream ca = null,ma =null,pa=null,sa=null,ta=null;
		try {
			ca = new FileInputStream(new File(folderpath+"/category.txt"));
			ma = new FileInputStream(new File(folderpath+"/manufacturer.txt"));
			pa = new FileInputStream(new File(folderpath+"/part.txt"));
			sa = new FileInputStream(new File(folderpath+"/salesperson.txt"));
			ta = new FileInputStream(new File(folderpath+"/transaction.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("File not exists");
			return;
		}

		InputStream[] iset = { ca, ma, pa, sa, ta };
		for (int i = 0; i < tablenames.length; i++) {
			insertinterface(tablenames[i], fieldname[i], iset[i]);
		}
		System.out.println("Processing.. Done! Data is inputted to the database!");
	}

	public static void shownumber() {
		String gen = "SELECT COUNT(*) FROM ";
		for(String item : tablenames){
			try {
				Statement sm = Console.cn.createStatement();
				ResultSet rs = sm.executeQuery(gen+item);
				rs.next();
				System.out.println(item+": "+rs.getString(1));
				rs.close();
				sm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				Errors.handleSQL(item,e);
			}	
		}
	}
	
}
