package yzz;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class Manager {
	public static String[] manmenu = { "Show the sales record of a saleperson within a period",
			"Show the total sales value of each manufacturer", "Show the N most popular part",
			"Return to the main menu" };

	private static String get_m_total = "SELECT M.mID, M.mName, M.totalvalue " + "FROM manufacturer M "
			+ "ORDER BY M.totalvalue DESC";

	public static void showrecord() {

		System.out.print("Enter the salesperson ID: ");
		int sid = Console.s.nextInt();
		Console.s.nextLine();
		System.out.print("Type in the starting date [dd/mm/yyyy]: ");
		String sdate = Console.s.nextLine();
		System.out.print("Type in the ending date [dd/mm/yyyy]: ");
		String edate = Console.s.nextLine();
		// System.out.println("Transaction Record: ");
		String query = "SELECT T.tID, P.pID, P.pName, M.mName, P.pPrice, T.tDate "
				+ "FROM transaction T, part P, manufacturer M " + "WHERE T.sID = " + sid + " AND T.pid = P.pid AND "
				+ "P.mid = M.mid AND " + "T.tDate BETWEEN TO_DATE('" + sdate + "', 'dd/mm/yyyy') AND " + "TO_DATE('"
				+ edate + "','dd/mm/yyyy') " + "ORDER BY T.tDate DESC";
		Statement st;
		try {
			st = Console.cn.createStatement();
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
			return;
		}
		try {
			ResultSet rs = st.executeQuery(query);
			System.out.println("| Transaction ID | Part ID | Part Name | Manufacturer | Price | Date ");
			SimpleDateFormat des = new SimpleDateFormat("dd/MM/yyyy");
			while(rs.next()){
				System.out.println("| "+rs.getInt(1)+" | "+rs.getInt(2)+" | "+rs.getString(3)+" | "+rs.getString(4)
				+" | "+rs.getInt(5)+" | "+des.format(rs.getDate(6))+" |");
			}
			rs.close();
			st.close();
		} catch (SQLException e) {
			Errors.handleSQL(query, e);
			return;
		}
		

	}

	public static void showsalesvalue() {
		// System.out.println(get_m_total);
		Statement st;
		try {
			st = Console.cn.createStatement();
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
			return;
		}

		try {
			ResultSet rs = st.executeQuery(get_m_total);
			System.out.println("| Manufacturer ID | Manufacturer Name | Total Sales Value |");
			while (rs.next()) {
				System.out.println("| " + rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getInt(3) + " |");
			}
			System.out.println("End of query");
			rs.close();
			st.close();
		} catch (SQLException e) {
			Errors.handleSQL(get_m_total, e);
		}

	}

	public static void showpopular() {
		System.out.print("Type in the number of parts: ");
		int n = Console.s.nextInt();
		Console.s.nextLine();
		String query = "SELECT T.pID, P.pName,COUNT(*) AS Num " + "FROM TRANSACTION T, Part P " + "WHERE T.pID = p.Pid "
				+ "GROUP BY T.pID, P.pName " + "ORDER BY Num DESC";
		Statement st;

		try {
			st = Console.cn.createStatement();
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
			return;
		}

		try {
			ResultSet rs = st.executeQuery(query);
			// st.close();
			System.out.println("| Part ID | Part Name | No. of Transaction |");
			// loop for n times
			for (int i = 0; i < n && rs.next() != false; i++) {
				System.out.println("|\t" + rs.getInt(1) + "|\t" + rs.getString(2) + "|\t" + rs.getInt(3) + "|");
			}
			System.out.println("End of query");
			rs.close();
			st.close();
		} catch (SQLException e) {
			Errors.handleSQL(query, e);
		}

	}
}
