package yzz;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Salesperson {
	public static String[] salemenu={"Search for parts", "Sell a part", "Return to the main menu"};
	
	//Part ID, Part Name, Manufacturer Name, Category Name, Available Quantity, Warranty Period and Part Price.
	public static void search(){
		System.out.print("Choose the search criterion: \n"
				+ "1. Part Name\n"
				+ "2. Manufacturer Name\n"
				+ "Choice: ");
		
		int choice1 = Console.read(2);
		if(choice1==0)	return;
		System.out.print("Type in the Search Keyword: ");
		String key = Console.s.nextLine();
		System.out.print("Choose ordering:\n"
				+ "1. By price, ascending order\n"
				+ "2. By price, descending order\n"
				+ "Choice: ");
		int choice2 = Console.read(2);
		if(choice2==0)	return;
		Console.s.nextLine();
		String query = "SELECT P.pID, P.pName, M.mName, P.cID, P.pAvailableQuantity, M.mWarrantyPeriod, P.pPrice "
				+ "FROM part P, manufacturer M "
				+ "WHERE P.mID = M.mID AND ";
		switch (choice1) {
		//By part name 
		case 1:
			query += "P.pName LIKE '%"+key+"%' "; 
			break;
		case 2:
			query += "M.mName LIKE '%"+key+"%' "; 
			break;
		}
		switch (choice2) {
		case 1:
			query += "ORDER BY P.pPrice ASC";
			break;

		case 2:
			query += "ORDER BY P.pPrice DESC";
			break;
		}
		try {
			//1-7
			Statement sm = Console.cn.createStatement();
			ResultSet rs = sm.executeQuery(query);
			System.out.println("| ID | Name | Manufacturer | Category | Quantity | Warranty | Price |");
			while (rs.next()) {
				for(int i=1;i<=7;i++){
					System.out.print("| "+rs.getString(i)+" ");
				}
				System.out.println("|");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Errors.handleSQL(query, e);
		}
		System.out.println("End of query");
		
		
	}
	
	public static void sell(){
		System.out.println("Enter The Part ID: ");
		int pid = Console.s.nextInt();
		Console.s.nextLine();
		System.out.println("Enter The Salesperson ID: ");
		int sid = Console.s.nextInt();
		Console.s.nextLine();
		//check if it is empty
		String em = "SELECT P.pAvailableQuantity, P.pName "
				+ "FROM part P "
				+ "WHERE P.pID = " + pid;
		Statement s;
		int currentamount;
		String name;
		try {
			s = Console.cn.createStatement();
			ResultSet rs = s.executeQuery(em);
			rs.next();
			currentamount = rs.getInt(1);
			name = rs.getString(2);
			rs.close();
			if (currentamount<=0) {
				System.out.println(name + ": Sold out! Not available!");
				return;
			}
			// when you have enough
			else {
				//Output information
				System.out.println("Product: "+name+"(id: "+pid+") Remaining Quantity: "+(currentamount-1));
				//update quanti1111111ty
				String up = "UPDATE part "
						+ "SET pAvailableQuantity = pAvailableQuantity-1 "
						+ "WHERE pID = " + pid;
				s.execute(up);
				s.close();
				//create transaction
				String tr = "INSERT INTO transaction(tID,pID,sID,tDate) "
						+ "VALUES(?,?,?,sysdate)";
				try{
					PreparedStatement p = Console.cn.prepareStatement(tr);
					//set pid
					p.setInt(2, pid);
					//set sid 
					p.setInt(3, sid);
					//set tid
					int m_t = getmaxtid();
					if (m_t == -1) {
						System.out.println("Cannot get Maximum tid...");
						p.close();
						return;
					}
					p.setInt(1, m_t+1);
					p.execute();
					p.close();
					System.out.println("Transaction updated, with tid: "+(m_t+1));
				}
				catch (SQLException e) {
					Errors.handleSQL(tr, e);
				}
				
			}
		} catch (SQLException e) {
			Errors.handleCreateSQL(e);
		}
		
	}

	private static int getmaxtid() {
		String query = "SELECT MAX(tID) FROM transaction";
		int a = -1;
		try {
			Statement st = Console.cn.createStatement();
			ResultSet rs = st.executeQuery(query);
			rs.next();
			a = rs.getInt(1);
			st.close();
			rs.close();
		} catch (SQLException e) {
			Errors.handleSQL(query, e);
		}
		return a;	
		
	}
}
